module Average3 where
average3 :: (Double,Double,Double) -> Double
average3 (x,y,z) = (x + y + z)/3